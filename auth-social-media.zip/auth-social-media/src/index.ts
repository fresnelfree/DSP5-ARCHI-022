import express from 'express';
import UserRouter from './routes/index';

const app = express();

app.use(express.json());
app.use('/routes',UserRouter.router);

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});