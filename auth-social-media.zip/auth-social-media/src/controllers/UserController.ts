// import { Request, Response } from 'express';
import User from '../models/User';

/**
 * Welcome Screen http://localhost:3000/
 */

const getAllUsers = (req, res) =>{    
  res.json({ 'title': 'UserController.getAllUsers()' })
}

export default module.exports = {
  getAllUsers
}