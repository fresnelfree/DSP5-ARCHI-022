
import express from 'express';
import UserController from '../controllers/UserController';

const router = express.Router();

// Define routes and connect them to controller methods
router.get('/helloworld', UserController.getAllUsers);

export default module.exports = {router};